# Install catboost - pip install catboost
# Importing Libraries
##
import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import *
from catboost import CatBoostClassifier
import pickle
import warnings
warnings.filterwarnings("ignore")

df = pd.read_csv('thyroid-disease-data.csv')

# Categorizing different classes into 3 major thyroid conditions: Hyperthyroid, Hypothyroid and Negative (No Thyroid Condition)
hyperthyroid_conditions = ['A', 'B', 'C', 'D', 'O', 'P', 'Q', 'S', 'T']
hypothyroid_conditions = ['E', 'F', 'G', 'H']
normal_conditions = ['-']

def categorize_target(value):
    # Split the diagnosis into parts for compound cases
    diagnoses = value.split('|')
    # Check for hyperthyroid conditions
    for diagnosis in diagnoses:
        if diagnosis in hyperthyroid_conditions:
            return 'Hyperthyroid'
    # Check for hypothyroid conditions
    for diagnosis in diagnoses:
        if diagnosis in hypothyroid_conditions:
            return 'Hypothyroid'

    for diagnosis in diagnoses:
        if diagnosis in normal_conditions:
            return 'Negative'

#Applying 'categorize_target' function on 'target' column to categorize the values into 3 classes
df['target'] = df['target'].apply(categorize_target)

# Imputing the missing values in 'sex' column with mode of the column
sex_mode = df['sex'].mode()[0]

# Imputing the missing values in 'sex' column with its mode
df['sex'] = df['sex'].fillna(sex_mode)

# List of columns that will be dropped
col_to_drop = ['TSH_measured', 'T3_measured', 'TT4_measured', 'T4U_measured', 'FTI_measured', 'TBG_measured', 'patient_id']

# Dropping the columns in the 'col_to_drop' list
df.drop(col_to_drop, axis = 1, inplace = True)

# List of columns containing missing values
col_with_null = ['TSH', 'T3', 'TT4', 'T4U', 'FTI', 'TBG']

# Imputing the missing values in columns, in 'col_with_null' list, with 0
for col in col_with_null:
    df[col] = df[col].fillna(0)

# Dropping the missing values
df.dropna(inplace=True)

# Dropping 'hypopituitary' column
df.drop('hypopituitary', axis = 1, inplace = True)

# Filtering the values in 'age' column
df = df[df['age'] <= 100]

# Creating a copy of 'df' without any null values for data visualization
df1 = df.copy()

# Creating an object for Label Encoder Class
le = LabelEncoder()

# Create mappings for categorical variables
sex_map = {'F':0, 'M':1}
obj_col_map = {'f':0, 't':1}

# Apply 'sex_map' on 'sex' column
df['sex'] = df['sex'].map(sex_map)

# Label Encoding the 'referral_source' column
df['referral_source'] = le.fit_transform(df['referral_source'])

# Apply 'obj_col_map' on columns with 'object' data type, except the 'target' column
for i in df.columns:
    if df[i].dtype == 'object' and i != 'target':
        df[i] = df[i].map(obj_col_map)

# Splits the DataFrame into features (x) and target variable (y)
x = df.drop('target', axis = 1)
y = df['target']

# Splitting the data into training and testing sets, maintaining the original class distribution
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42, stratify=y)

print(x_train.shape)
print(x_test.shape)
print(y_train.shape)
print(y_test.shape)

cat_features = x_train.select_dtypes(include=['object']).columns.tolist()

# Training the CatBoost Classifier with Balanced Class Weights and L2 Regularization
cat3 = CatBoostClassifier(auto_class_weights='Balanced', cat_features=cat_features, random_state=42, verbose = False, l2_leaf_reg=1)
cat3.fit(x_train, y_train)
# Making Predictions
y_pred = cat3.predict(x_test)
y_score = cat3.predict_proba(x_test)


#Evaluate
print(f'\n {confusion_matrix(y_test, y_pred)}\n')
print(f'Accuracy: {accuracy_score(y_test, y_pred)}\n')

# Save the trained model to a pickle file
with open('final_model.pkl', 'wb') as file:
    pickle.dump(cat3, file)
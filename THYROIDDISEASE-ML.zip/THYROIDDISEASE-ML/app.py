from flask import Flask, render_template, request
import pickle
import pandas as pd
import os

app = Flask(__name__)

# Load the trained model
model_path = 'final_model.pkl'
with open(model_path, 'rb') as file:
    model = pickle.load(file)


@app.route('/')
def home():
    return render_template('home.html')
@app.route('/predict_form')
def predict_form():
    return render_template('index.html')
@app.route('/thyroid_info')
def thyroid_info():
    return render_template('thyroid_info.html')


@app.route('/predict', methods=['POST'])
def predict():
    # Get feature names and their order from the model
    feature_names = model.feature_names_

    # Initialize a dictionary to store features
    input_data = {}

    # Extract numerical features
    numerical_features = ['age', 'TSH', 'T3', 'TT4', 'T4U', 'FTI', 'TBG']
    for feature in numerical_features:
        input_data[feature] = float(request.form.get(feature, 0))

    # Extract binary features (mapped as 0=f, 1=t)
    binary_features = [
        'on_thyroxine', 'query_on_thyroxine', 'on_antithyroid_meds',
        'sick', 'pregnant', 'thyroid_surgery', 'I131_treatment', 'query_hypothyroid',
        'query_hyperthyroid', 'lithium', 'goitre', 'tumor', 'psych'
    ]
    for feature in binary_features:
        input_data[feature] = 1 if request.form.get(feature) == 'true' else 0

    # Map sex (F=0, M=1)
    input_data['sex'] = 1 if request.form.get('sex') == 'M' else 0

    # Convert referral source to a number
    referral_source = request.form.get('referral_source', 'other')
    # This is a placeholder - in a real app, you'd need to ensure this matches
    # the same encoding used during training
    referral_source_map = {
        'SVHC': 0, 'SVHD': 1, 'SVI': 2, 'other': 3, 'stmw': 4, 'STMW': 4
    }
    input_data['referral_source'] = referral_source_map.get(referral_source, 3)

    # Create a DataFrame with the features, making sure to use the exact same order
    # as the model expects
    df = pd.DataFrame([input_data])

    # Reorder columns to match the model's expected order
    if feature_names:
        # If the model has feature names, use them for ordering
        df = df[feature_names]
    else:
        # If feature names aren't available, we'll need to infer them from the training data
        # This is a simplified approach - for production, ensure exact feature order matches
        print("Warning: Model doesn't provide feature names. Using alphabetical order.")
        df = df.reindex(sorted(df.columns), axis=1)

    # Print feature names to help debug
    print("Feature columns in input data:", df.columns.tolist())

    # Make prediction
    prediction = model.predict(df)[0]

    # Get prediction probabilities
    probabilities = model.predict_proba(df)[0]

    # Create a dictionary of class probabilities
    classes = model.classes_
    prob_dict = {cls: round(prob * 100, 2) for cls, prob in zip(classes, probabilities)}

    return render_template('result.html', prediction=prediction, probabilities=prob_dict)


if __name__ == '__main__':
    app.run(debug=True, port=5006)